package ch.lukas.filemanager;

import ch.lukas.filemanager.view.Filemanager;

/**
 * The main class, starting the GUI
 * @author lukas
 */
public class App {

    public static void main( String[] args ) {
        new Filemanager();
    }
}
